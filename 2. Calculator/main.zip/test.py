p = [(j, i) for j in range(5) for i in range(4)]
print(p)