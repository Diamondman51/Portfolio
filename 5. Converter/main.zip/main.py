import time

from PySide6.QtWidgets import QApplication

from ui import Ui_MainWindow
from widget import Widget

try:
    app = QApplication()
    window = Widget()
    window.show()
    app.exec()
    input()
    time.sleep(10)
except FileNotFoundError:
    input()
    time.sleep(20)