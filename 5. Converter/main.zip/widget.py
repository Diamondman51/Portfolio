import sys

from PySide6.QtGui import QTextCursor, Qt
from PySide6.QtWidgets import QMainWindow

from ui import Ui_MainWindow
import requests
import json
class Widget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.get_curency()
        self.exit.clicked.connect(self.chiq)
        self.text_usd.textChanged.connect(self.change)
        # self.text_usd.textChanged.connect(self.change2)
        self.text_uzs.setObjectName('uzs')
        self.text_usd.setObjectName('usd')
        self.comboBox.setObjectName('uzs')
        self.gridLayout.setObjectName('ggrid')
        self.exit.setObjectName('exit')
        self.setObjectName('main')
        self.setWindowTitle('Converter')
        self.text_uzs.moveCursor(QTextCursor.EndOfLine)
        self.comboBox.currentTextChanged.connect(self.change)
        self.setStyleSheet(open('style.css').read())

    def get_curency(self):
        url = 'https://cbu.uz/uz/arkhiv-kursov-valyut/json/'

        source = requests.get(url).text
        jjson = json.loads(source)
        # soup = bs4.BeautifulSoup(source, 'lxml')

        with open('currency.txt', 'w') as f:
            for i in range(3):
                f.write(f'{jjson[i]["Ccy"]} : {jjson[i]["Rate"]}\n')
    def chiq(self):
        sys.exit()

    currency = {}

    with open('currency.txt', 'r') as f:
        for _ in range(3):
            line = f.readline().split(":")
            currency[line[0].strip()] = line[1].strip()

    print(currency)
    def change(self):
        text_usd = self.text_usd.toPlainText()
        if text_usd == '':
            # self.text_usd.setPlainText('0')
            pass
        else:
            # text_usd.replace('0', '')
            self.text_uzs.setPlainText(f"{(int(text_usd) * float(self.currency[(self.comboBox.currentText())])):,} so'm")

    # def change2(self):
    #     text_usd = self.text_usd.toPlainText()
    #     self.text_uzs.setPlainText(str(int(text_usd) / self.currency))