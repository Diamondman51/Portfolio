import requests
import bs4
import json
def get_curency():
    url = 'https://cbu.uz/uz/arkhiv-kursov-valyut/json/'

    source = requests.get(url).text
    jjson = json.loads(source)
    # soup = bs4.BeautifulSoup(source, 'lxml')

    with open('currency.txt', 'w') as f:
        for i in range(3):
            f.write(f'{jjson[i]["Ccy"]} : {jjson[i]["Rate"]}\n')
get_curency()